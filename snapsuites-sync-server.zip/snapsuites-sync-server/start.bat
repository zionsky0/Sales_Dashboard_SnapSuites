@echo off
title SnapSuites Sync Server
cd /d "%~dp0"
echo Starting SnapSuites Sync Server on port 3001...
node server.js
pause
