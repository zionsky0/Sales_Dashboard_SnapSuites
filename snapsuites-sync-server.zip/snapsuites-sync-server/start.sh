#!/bin/bash
# 1-Click Startup for Mac / Linux
cd "$(dirname "$0")"
echo "Starting SnapSuites Sync Server on port 3001..."
node server.js
