# SnapSuites Sync Server (Playit.gg / Self-Hosted Backend)

This is the standalone backend server for the **SnapSuites Sales Hub & CRM**. It requires **zero external npm installations** (runs purely on Node.js built-ins) and stores all leads, quotes, prospects, and venue statuses in `data/sales_hub_db.json`.

---

## 🚀 Quick Start on Your Server Machine

### 1. Requirements
* [Node.js](https://nodejs.org) (v18.0.0 or newer) installed on your server machine.

---

### 2. Running the Server

#### On Windows:
Double-click `start.bat` or run:
```cmd
node server.js
```

#### On Linux / Mac:
```bash
chmod +x start.sh
./start.sh
# Or directly:
node server.js
```

#### To Run 24/7 in the Background with PM2 (Optional):
```bash
npm install -g pm2
pm2 start server.js --name "snapsuites-server"
pm2 save
pm2 startup
```

---

## 🌐 Connecting with Playit.gg

1. Open your **Playit.gg** client / dashboard on your server machine.
2. Create a new **HTTP / Custom Tunnel**.
3. Set Local Port: **`3001`** (and IP `127.0.0.1` or `localhost`).
4. Playit.gg will give you a public URL (e.g. `https://my-sales-hub.playit.gg`).

---

## 📱 Connecting in the Dashboard
1. Open your SnapSuites dashboard (on phone, iPad, or laptop).
2. Go to **Settings (⚙️)**.
3. Paste your Playit.gg tunnel URL into **Server / Tunnel URL**.
4. Click **⚡ Test Connection & Pull Data**.
5. You're done! All devices will now sync in real time.
